function validar(){
            
    var nome = document.getElementById("name");
    var sobrenome = document.getElementById("sobrenome");
    var tel = document.getElementById("tel");
    var email = document.getElementById("email");
    var idade = document.getElementById("idade");
    var rede = document.getElementById("rede");
    var anos = document.getElementById("Nascimento").value;
    if(nome.value == '' || sobrenome == '' || tel == '' || email == '' || idade == '' || rede == '' || anos == '') 
    {
        alert("Preencha todos os dados que estão em vermelho corretamente")
        nome.focus();
    }
    
}

function calculateAge(dobString) {
		 
    var dob = new Date(dobString);
    var currentDate = new Date();
    var currentYear = currentDate.getFullYear();
    var birthdayThisYear = new Date(dob.getDay(), dob.getMonth(), currentYear);
    var age = currentYear - dob.getFullYear();
  
    if(birthdayThisYear > currentDate) {
         
       age--;
    } 
       return age;
 
 }

   function idad(){

    var dataaNasc = document.getElementById("Nascimento").value;
    var idadef = calculateAge(dataaNasc);

    document.getElementById("idade").value = idadef;

   }